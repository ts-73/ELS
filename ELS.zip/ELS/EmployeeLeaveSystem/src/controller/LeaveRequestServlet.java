package controller;

import java.io.IOException;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import dao.LeaveDAO;
import model.Leave;

@WebServlet("/leaveRequests")
public class LeaveRequestServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        LeaveDAO leaveDAO = new LeaveDAO();

        // Debugging line to indicate that leave requests are being fetched
        System.out.println("Fetching leave requests...");
        
        // Retrieve leave requests from the database
        List<Leave> leaveRequests = leaveDAO.getAllLeaveRequests();
        
        // Debugging line to log the size of the leave requests list
        System.out.println("Leave requests size: " + leaveRequests.size());

        // Set the leave requests in request scope
        request.setAttribute("leaveRequests", leaveRequests);

        // Set message attribute if no leave requests found
        if (leaveRequests.isEmpty()) {
            request.setAttribute("message", "No leave requests found.");
        }

        // Forward the request to the JSP page
        request.getRequestDispatcher("viewleaveRequests.jsp").forward(request, response);
    }
}
