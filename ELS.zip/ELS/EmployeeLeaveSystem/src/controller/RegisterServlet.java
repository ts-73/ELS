package controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.UserDAO;
import model.User;

@WebServlet("/RegisterServlet")
public class RegisterServlet extends HttpServlet {

    // Handle HTTP POST requests for user registration
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        
        // Get registration data from the form submission
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        String email = request.getParameter("email");
        String role = request.getParameter("role"); // Admin or Employee
        String department = request.getParameter("department");

        // Initialize UserDAO to interact with the database
        UserDAO userDAO = new UserDAO();
        
        // Check if the username already exists in the database
        if (userDAO.isUsernameTaken(username)) {
            // If username is taken, redirect to registration error page
            response.sendRedirect("registerError.jsp");
        } else {
            // If username is available, create a new user
            User newUser = new User();
            newUser.setUsername(username);
            newUser.setPassword(password);  // In real applications, passwords should be hashed
            newUser.setEmail(email);
            newUser.setRole(role);
            newUser.setDepartment(department);

            // Try to register the new user in the database
            try {
                boolean isRegistered = userDAO.registerUser(newUser);

                // If registration is successful, set employeeId in session and redirect to success page
                if (isRegistered) {
                    // Assuming that UserDAO provides a method to get the generated employeeId for the new user
                    String employeeId = userDAO.getEmployeeId(newUser); // Retrieve the generated employeeId
                    
                    // Set employeeId in the session
                    HttpSession session = request.getSession();
                    session.setAttribute("employeeId", employeeId);
                    
                    // Redirect to the success page
                    response.sendRedirect("registerSuccess.jsp");
                } else {
                    response.sendRedirect("registerError.jsp"); // If registration fails
                }
            } catch (Exception e) {
                // Handle any errors during registration
                e.printStackTrace();
                response.sendRedirect("registerError.jsp");
            }
        }
    }
}
