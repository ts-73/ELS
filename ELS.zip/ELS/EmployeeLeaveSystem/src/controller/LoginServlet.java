package controller;

import dao.LeaveDAO;
import dao.UserDAO;
import model.User;

import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;

/**
 * Servlet for handling user login.
 */
@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String username = request.getParameter("username");
        String password = request.getParameter("password");

        UserDAO userDAO = new UserDAO();
        LeaveDAO leaveDAO = new LeaveDAO();
        try {
            User user = userDAO.authenticateUser(username, password);

            if (user != null) {
                HttpSession session = request.getSession();
                session.setAttribute("loggedInUser", user);  // Store user object
                session.setAttribute("employeeId", user.getId()); // Store employee ID
                System.out.println("Session Set: Employee ID = " + user.getId()); // Debug log

                if ("Admin".equalsIgnoreCase(user.getRole())) {
                    response.sendRedirect("adminDashboard.jsp");
                } else {
                    response.sendRedirect("employeeDashboard.jsp");
                }
            } else {
                response.sendRedirect("loginError.jsp");
            }
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("loginError.jsp");
        }
    }
}
