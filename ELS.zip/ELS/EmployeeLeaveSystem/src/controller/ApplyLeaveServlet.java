package controller;

import dao.LeaveDAO;
import model.Leave;

import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

@WebServlet("/ApplyLeaveServlet")
public class ApplyLeaveServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Retrieve form data
        String employeeIdStr = request.getParameter("employeeId"); // Take employeeId from the form
        String leaveType = request.getParameter("leaveType");
        String fromDate = request.getParameter("fromDate");
        String toDate = request.getParameter("toDate");
        String reason = request.getParameter("reason");

        // Validate input fields
        if (employeeIdStr == null || leaveType == null || fromDate == null || toDate == null || reason == null ||
            employeeIdStr.isEmpty() || leaveType.isEmpty() || fromDate.isEmpty() || toDate.isEmpty() || reason.isEmpty()) {
            request.setAttribute("errorMessage", "Please fill in all the fields.");
            RequestDispatcher dispatcher = request.getRequestDispatcher("apply_leave.jsp");
            dispatcher.forward(request, response);
            return;
        }

        try {
            // Parse the employee ID
            int employeeId = Integer.parseInt(employeeIdStr);

            // Parse the date strings into Date objects
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            Date startDate = sdf.parse(fromDate);
            Date endDate = sdf.parse(toDate);

            // Validate that the end date is not before the start date
            if (endDate.before(startDate)) {
                request.setAttribute("errorMessage", "End date cannot be before start date.");
                RequestDispatcher dispatcher = request.getRequestDispatcher("apply_leave.jsp");
                dispatcher.forward(request, response);
                return;
            }

            // Create a Leave object
            Leave leave = new Leave();
            leave.setEmployeeId(employeeId); // Set the employee ID from form input
            leave.setLeaveType(leaveType);
            leave.setStartDate(startDate);
            leave.setEndDate(endDate);
            leave.setReason(reason);
            leave.setStatus("Pending"); // Default status is 'Pending'

            // Call LeaveDAO to save the leave request
            LeaveDAO leaveDAO = new LeaveDAO();
            boolean isApplied = leaveDAO.applyLeave(leave);

            if (isApplied) {
                // Redirect to success page or display success message
                response.sendRedirect("leaveSuccess.jsp");
            } else {
                // Handle database save failure
                request.setAttribute("errorMessage", "An error occurred while applying for leave. Please try again.");
                RequestDispatcher dispatcher = request.getRequestDispatcher("apply_leave.jsp");
                dispatcher.forward(request, response);
            }

        } catch (NumberFormatException e) {
            // Handle invalid employee ID
            request.setAttribute("errorMessage", "Invalid Employee ID. Please enter a valid number.");
            RequestDispatcher dispatcher = request.getRequestDispatcher("apply_leave.jsp");
            dispatcher.forward(request, response);
        } catch (Exception e) {
            e.printStackTrace();
            // Handle other exceptions
            request.setAttribute("errorMessage", "An unexpected error occurred. Please try again.");
            RequestDispatcher dispatcher = request.getRequestDispatcher("apply_leave.jsp");
            dispatcher.forward(request, response);
        }
    }
}
