package controller;

import dao.UserDAO;
import model.User;

import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.util.List;

/**
 * Servlet for managing users in the admin panel.
 */
@WebServlet("/manageUsers")
public class ManageUsersServlet extends HttpServlet {

    /**
     * Handles GET requests: Fetches and displays the list of users.
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        UserDAO userDAO = new UserDAO();
        List<User> users = userDAO.getAllUsers(); // Retrieve all users from the database
        
        request.setAttribute("users", users); // Pass user list to JSP
        
        String action = request.getParameter("action");
        
        if (action != null && "editUser".equals(action)) {
            int userId = Integer.parseInt(request.getParameter("id"));
            User user = userDAO.getUserById(userId); // Fetch user details for editing
            
            request.setAttribute("user", user); // Pass the user to the JSP for editing
            RequestDispatcher dispatcher = request.getRequestDispatcher("editUser.jsp");
            dispatcher.forward(request, response);
            return;
        }
        
        // Forward the request to the JSP page for user list display
        RequestDispatcher dispatcher = request.getRequestDispatcher("manageUsers.jsp");
        dispatcher.forward(request, response);
    }

    /**
     * Handles POST requests for adding or deleting a user.
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");

        if (action == null) {
            response.sendRedirect("manageUsers?error=invalidAction");
            return;
        }

        UserDAO userDAO = new UserDAO();
        
        if ("addUser".equals(action)) {
            // Handling adding a new user
            String username = request.getParameter("username");
            String password = request.getParameter("password");
            String email = request.getParameter("email");
            String role = request.getParameter("role");
            String department = request.getParameter("department");

            // Validate fields (basic example)
            if (username == null || password == null || email == null || role == null || department == null) {
                response.sendRedirect("manageUsers?error=missingFields");
                return;
            }

            User newUser = new User(username, password, email, role, department);
            boolean success = userDAO.registerUser(newUser); // Add user to database

            response.sendRedirect("manageUsers?success=" + success);
            return;
        } 
        
        if ("deleteUser".equals(action)) {
            // Handling user deletion
            try {
                int userId = Integer.parseInt(request.getParameter("userId"));
                boolean success = userDAO.deleteUser(userId);

                response.sendRedirect("manageUsers?deleteSuccess=" + success);
            } catch (NumberFormatException e) {
                response.sendRedirect("manageUsers?error=invalidUserId");
            }
            return;
        }

        response.sendRedirect("manageUsers?error=unknownAction");
    }
}
