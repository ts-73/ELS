package controller;

import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
@WebServlet("/LogoutServlet")
public class LogoutServlet extends HttpServlet {

    // Handle HTTP GET requests for logging out
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        
        // Get the current session
        HttpSession session = request.getSession(false); // Don't create a new session if one doesn't exist
        
        if (session != null) {
            // Invalidate the session to log out the user
            session.invalidate();
        }

        // Redirect the user to the login page
        response.sendRedirect("login.jsp");
    }
}
