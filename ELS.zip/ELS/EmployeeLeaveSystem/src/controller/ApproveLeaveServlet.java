package controller;

import dao.LeaveDAO;
import model.Leave;
import model.LeaveBalance;

import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
@WebServlet("/ApproveLeaveServlet")
public class ApproveLeaveServlet extends HttpServlet {

    // Handle HTTP POST requests
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        
        // Get leave ID and status (approve or reject) from the form submission
        int leaveId = Integer.parseInt(request.getParameter("leaveId"));
        String status = request.getParameter("status");

        // Initialize LeaveDAO
        LeaveDAO leaveDAO = new LeaveDAO();

        // Try to update the leave status
        try {
            // Retrieve the leave request from the database
            Leave leave = leaveDAO.getLeaveById(leaveId);

            // If leave exists, update its status
            if (leave != null) {
                leave.setStatus(status); // Set the status to either "Approved" or "Rejected"
                
                // Update the leave status in the database
                boolean isUpdated = leaveDAO.updateLeaveStatus(leave);

                if (isUpdated) {
                    // Redirect to the leave approval page with success message
                    response.sendRedirect("approveLeaveSuccess.jsp");
                } else {
                    // Redirect to the leave approval page with error message
                    response.sendRedirect("approveLeaveError.jsp");
                }
            } else {
                // If the leave request is not found, show an error
                response.sendRedirect("approveLeaveError.jsp");
            }
        } catch (Exception e) {
            // Handle errors during the process
            e.printStackTrace();
            response.sendRedirect("approveLeaveError.jsp");
        }
    }
}
