package controller;

import dao.LeaveDAO;
import model.Leave;

import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.util.List;

@WebServlet("/ViewLeaveStatusServlet")
public class ViewLeaveStatusServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession(false); // Avoid creating a new session if one doesn't exist

        if (session == null || session.getAttribute("employeeId") == null) {
            // Redirect to login page if session is invalid or employeeId is missing
            response.sendRedirect("login.jsp");
            return;
        }

        try {
            // Retrieve employeeId from session
            int employeeId = (int) session.getAttribute("employeeId");

            // Fetch leave status data from the database using LeaveDAO
            LeaveDAO leaveDAO = new LeaveDAO();
            List<Leave> leaveList = leaveDAO.getLeaveStatusByEmployee(employeeId);

            // Set the leave data as a request attribute
            request.setAttribute("leaveList", leaveList);

            // Forward the request to the leave_status.jsp page
            RequestDispatcher dispatcher = request.getRequestDispatcher("view_leave_status.jsp");
            dispatcher.forward(request, response);

        } catch (Exception e) {
            // Log the error and redirect to an error page or display an error message
            e.printStackTrace();
            response.sendRedirect("error.jsp");
        }
    }
}
