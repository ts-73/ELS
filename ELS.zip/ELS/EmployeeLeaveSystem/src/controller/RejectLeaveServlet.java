package controller;

import dao.LeaveDAO;
import model.Leave;

import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
@WebServlet("/RejectLeaveServlet")
public class RejectLeaveServlet extends HttpServlet {

    // Handle HTTP POST requests for rejecting a leave request
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        // Get the leave ID from the request
        int leaveId = Integer.parseInt(request.getParameter("leaveId"));

        // Initialize LeaveDAO to interact with the database
        LeaveDAO leaveDAO = new LeaveDAO();

        // Try to reject the leave
        try {
            // Retrieve the leave request from the database
            Leave leave = leaveDAO.getLeaveById(leaveId);

            // If leave exists, update its status to "Rejected"
            if (leave != null) {
                leave.setStatus("Rejected");

                // Update the leave status in the database
                boolean isUpdated = leaveDAO.updateLeaveStatus(leave);

                if (isUpdated) {
                    // Redirect to the success page if the leave was rejected successfully
                    response.sendRedirect("rejectLeaveSuccess.jsp");
                } else {
                    // Redirect to error page if there was an issue updating the status
                    response.sendRedirect("rejectLeaveError.jsp");
                }
            } else {
                // If leave request is not found, show an error
                response.sendRedirect("rejectLeaveError.jsp");
            }
        } catch (Exception e) {
            // Handle errors during the process
            e.printStackTrace();
            response.sendRedirect("rejectLeaveError.jsp");
        }
    }
}
