package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import model.Leave;
import model.User;

public class AdminDAO {

    // Approve a leave request
    public boolean approveLeave(int leaveId) {
        String sql = "UPDATE leaves SET status = 'Approved' WHERE leave_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, leaveId);
            int rowsUpdated = ps.executeUpdate();
            return rowsUpdated > 0;
        } catch (SQLException e) {
            System.out.println("Error approving leave: " + e.getMessage());
        }
        return false;
    }

    // Reject a leave request
    public boolean rejectLeave(int leaveId) {
        String sql = "UPDATE leaves SET status = 'Rejected' WHERE leave_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, leaveId);
            int rowsUpdated = ps.executeUpdate();
            return rowsUpdated > 0;
        } catch (SQLException e) {
            System.out.println("Error rejecting leave: " + e.getMessage());
        }
        return false;
    }

    // Get all pending leave requests
    public List<Leave> getPendingLeaves() {
        List<Leave> leaves = new ArrayList<>();
        String sql = "SELECT l.leave_id, l.employee_id, l.leave_type, l.start_date, l.end_date, l.reason, l.status, u.username "
                   + "FROM leaves l JOIN users u ON l.employee_id = u.id WHERE l.status = 'Pending'";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                Leave leave = new Leave();
                leave.setLeaveId(rs.getInt("leave_id"));
                leave.setEmployeeId(rs.getInt("employee_id"));
                leave.setLeaveType(rs.getString("leave_type"));
                leave.setStartDate(rs.getDate("start_date"));
                leave.setEndDate(rs.getDate("end_date"));
                leave.setReason(rs.getString("reason"));
                leave.setStatus(rs.getString("status"));
             
                leaves.add(leave);
            }
        } catch (SQLException e) {
            System.out.println("Error fetching pending leaves: " + e.getMessage());
        }
        return leaves;
    }

    // Get all employees
    public List<User> getAllEmployees() {
        List<User> employees = new ArrayList<>();
        String sql = "SELECT * FROM users WHERE role = 'Employee'";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                User user = new User();
                user.setId(rs.getInt("id"));
                user.setUsername(rs.getString("username"));
                user.setEmail(rs.getString("email"));
                user.setDepartment(rs.getString("department"));
                employees.add(user);
            }
        } catch (SQLException e) {
            System.out.println("Error fetching employees: " + e.getMessage());
        }
        return employees;
    }
}
