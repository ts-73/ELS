package dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import model.Leave;
import model.LeaveBalance;

public class LeaveDAO {

    // Method to apply for leave
	public boolean applyLeave(Leave leave) {
	    if (!checkEmployeeExists(leave.getEmployeeId())) {
	        System.out.println("Error: Employee ID does not exist in the users table.");
	        return false; // Prevent inserting an invalid foreign key reference
	    }

	    String sql = "INSERT INTO leaves (employee_id, leave_type, start_date, end_date, reason, status) VALUES (?, ?, ?, ?, ?, ?)";
	    try (Connection conn = DBConnection.getConnection();
	         PreparedStatement ps = conn.prepareStatement(sql)) {

	        String leaveType = mapLeaveType(leave.getLeaveType());

	        ps.setInt(1, leave.getEmployeeId());
	        ps.setString(2, leaveType);
	        ps.setDate(3, new java.sql.Date(leave.getStartDate().getTime()));
	        ps.setDate(4, new java.sql.Date(leave.getEndDate().getTime()));
	        ps.setString(5, leave.getReason());
	        ps.setString(6, "Pending"); // Default status is Pending

	        int rowsInserted = ps.executeUpdate();
	        return rowsInserted > 0;
	    } catch (SQLException e) {
	        System.out.println("Error applying leave: " + e.getMessage());
	    }
	    return false;
	}


	public boolean checkEmployeeExists(int employeeId) {
	    String sql = "SELECT COUNT(*) FROM users WHERE id = ?";
	    try (Connection conn = DBConnection.getConnection();
	         PreparedStatement ps = conn.prepareStatement(sql)) {
	        ps.setInt(1, employeeId);
	        try (ResultSet rs = ps.executeQuery()) {
	            if (rs.next()) {
	                return rs.getInt(1) > 0; // Returns true if the employee exists
	            }
	        }
	    } catch (SQLException e) {
	        System.out.println("Error checking employee existence: " + e.getMessage());
	    }
	    return false;
	}


	// Map leave types to database values
    private String mapLeaveType(String leaveType) {
        if ("Sick Leave".equals(leaveType)) {
            return "Sick";
        } else if ("Casual Leave".equals(leaveType)) {
            return "Casual";
        } else if ("Vacation Leave".equals(leaveType)) {
            return "Earned";
        }
        return leaveType;
    }

    // Method to update the leave balance
    public boolean updateLeaveBalance(int employeeId, String leaveType, int daysRequested) {
        String sql = "UPDATE leave_balance SET balance = balance - ? WHERE employee_id = ? AND leave_type = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, daysRequested);
            ps.setInt(2, employeeId);
            ps.setString(3, leaveType);
            int rowsUpdated = ps.executeUpdate();
            return rowsUpdated > 0;
        } catch (SQLException e) {
            System.out.println("Error updating leave balance: " + e.getMessage());
        }
        return false;
    }


    // Method to get leave history
    public List<Leave> getLeaveHistory(int employeeId) {
        String sql = "SELECT * FROM leaves WHERE employee_id = ?";
        List<Leave> leaveList = new ArrayList<>();
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, employeeId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Leave leave = new Leave();
                    leave.setLeaveId(rs.getInt("leave_id"));
                    leave.setEmployeeId(rs.getInt("employee_id"));
                    leave.setLeaveType(rs.getString("leave_type"));
                    leave.setStartDate(rs.getDate("start_date"));
                    leave.setEndDate(rs.getDate("end_date"));
                    leave.setReason(rs.getString("reason"));
                    leave.setStatus(rs.getString("status"));
                    leaveList.add(leave);
                }
            }
        } catch (SQLException e) {
            System.out.println("Error fetching leave history: " + e.getMessage());
        }
        return leaveList;
    }
   
    public List<Leave> getAllLeaveRequests() {
        String sql = "SELECT * FROM leaves";  // Assuming "leaves" is the table name in your database
        List<Leave> leaveList = new ArrayList<>();

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            // Iterate through the result set and create Leave objects
            while (rs.next()) {
                Leave leave = new Leave();
                leave.setLeaveId(rs.getInt("leave_id"));
                leave.setEmployeeId(rs.getInt("employee_id"));
                leave.setLeaveType(rs.getString("leave_type"));
                leave.setStartDate(rs.getDate("start_date"));
                leave.setEndDate(rs.getDate("end_date"));
                leave.setReason(rs.getString("reason"));
                leave.setStatus(rs.getString("status"));
                
                // Add each leave request to the list
                leaveList.add(leave);
            }

        } catch (SQLException e) {
            System.out.println("Error fetching all leave requests: " + e.getMessage());
        }

        return leaveList;
    }


    // Method to check leave balance
    public boolean hasSufficientBalance(int employeeId, String leaveType, int daysRequested) {
        String sql = "SELECT balance FROM leave_balance WHERE employee_id = ? AND leave_type = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, employeeId);
            ps.setString(2, leaveType);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    int balance = rs.getInt("balance");
                    return balance >= daysRequested;
                }
            }
        } catch (SQLException e) {
            System.out.println("Error checking leave balance: " + e.getMessage());
        }
        return false;
    }

    // Method to get leave details by leaveId
    public Leave getLeaveById(int leaveId) {
        String sql = "SELECT * FROM leaves WHERE leave_id = ?";
        Leave leave = null;
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, leaveId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    leave = new Leave();
                    leave.setLeaveId(rs.getInt("leave_id"));
                    leave.setEmployeeId(rs.getInt("employee_id"));
                    leave.setLeaveType(rs.getString("leave_type"));
                    leave.setStartDate(rs.getDate("start_date"));
                    leave.setEndDate(rs.getDate("end_date"));
                    leave.setReason(rs.getString("reason"));
                    leave.setStatus(rs.getString("status"));
                }
            }
        } catch (SQLException e) {
            System.out.println("Error fetching leave by ID: " + e.getMessage());
        }
        return leave;
    }

    // Method to update leave status
    public boolean updateLeaveStatus(Leave leave) {
        String sql = "UPDATE leaves SET status = ? WHERE leave_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, leave.getStatus());
            ps.setInt(2, leave.getLeaveId());
            int rowsUpdated = ps.executeUpdate();
            return rowsUpdated > 0;
        } catch (SQLException e) {
            System.out.println("Error updating leave status: " + e.getMessage());
        }
        return false;
    }

    // Method to fetch leaves by username
    public List<Leave> getLeavesByUsername(String username) {
        String sql = "SELECT * FROM leaves WHERE username = ?";
        List<Leave> leaves = new ArrayList<>();
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, username);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Leave leave = new Leave();
                    leave.setLeaveId(rs.getInt("leave_id"));
                    leave.setStartDate(rs.getDate("start_date"));
                    leave.setEndDate(rs.getDate("end_date"));
                    leave.setReason(rs.getString("reason"));
                    leave.setStatus(rs.getString("status"));
                    leave.setComments(rs.getString("comments"));
                    leaves.add(leave);
                }
            }
        } catch (SQLException e) {
            System.out.println("Error fetching leaves by username: " + e.getMessage());
        }
        return leaves;
    }

    public List<Leave> getLeaveStatusByEmployee(int employeeId) {
        String sql = "SELECT * FROM leaves WHERE employee_id = ?";  // Assuming employee_id is the field in the table
        List<Leave> leaves = new ArrayList<>();
        
        // Try-with-resources to manage database connection and resources
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setInt(1, employeeId);  // Set the employeeId parameter
            
            // Execute the query
            try (ResultSet rs = ps.executeQuery()) {
                // Process the result set and map each row to a Leave object
                while (rs.next()) {
                    Leave leave = new Leave();
                    leave.setLeaveId(rs.getInt("leave_id"));
                    leave.setStartDate(rs.getDate("start_date"));
                    leave.setEndDate(rs.getDate("end_date"));
                    leave.setReason(rs.getString("reason"));
                    leave.setStatus(rs.getString("status"));
                    leave.setComments(rs.getString("comments"));
                    leaves.add(leave);
                }
            }
        } catch (SQLException e) {
            System.out.println("Error fetching leave status by employee ID: " + e.getMessage());
        }
        
        // Return the list of leaves
        return leaves;
    }public List<Leave> getLeaveRequests(String role, HttpServletRequest request) {
        List<Leave> leaveRequests = new ArrayList<>();
        String sql;
        HttpSession session = request.getSession(false);
        int employeeId = 0;

        // Check if the user is an employee and retrieve the employee ID
        if (!"Admin".equalsIgnoreCase(role)) {
            employeeId = (Integer) session.getAttribute("employeeId");
            sql = "SELECT * FROM leaves WHERE employee_id = ?";
        } else {
            sql = "SELECT * FROM leaves";  // Admin can view all requests
        }

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            if (!"Admin".equalsIgnoreCase(role)) {
                ps.setInt(1, employeeId);  // Set employee ID for non-admin users
            }

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Leave leave = new Leave();
                    leave.setLeaveId(rs.getInt("id"));
                    leave.setEmployeeId(rs.getInt("employee_id"));
                    leave.setLeaveType(rs.getString("leave_type"));
                    leave.setStartDate(rs.getDate("start_date"));
                    leave.setEndDate(rs.getDate("end_date"));
                    leave.setReason(rs.getString("reason"));
                    leave.setStatus(rs.getString("status"));
                    leaveRequests.add(leave);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return leaveRequests;
    }



    public boolean hasLeaveBalance(int employeeId) {
        String sql = "SELECT COUNT(*) FROM leave_balance WHERE employee_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, employeeId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1) > 0; // Returns true if leave balance exists, otherwise false
                }
            }
        } catch (SQLException e) {
            System.out.println("Error checking leave balance: " + e.getMessage());
        }
        return false;
    }
    public void insertDefaultLeaveBalance(int employeeId) {
        String sql = "INSERT INTO leave_balance (employee_id, leave_type, balance) VALUES (?, ?, ?)";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            // Add Sick leave
            ps.setInt(1, employeeId);
            ps.setString(2, "Sick");
            ps.setInt(3, 8);
            ps.addBatch();
            
            // Add Casual leave
            ps.setString(2, "Casual");
            ps.setInt(3, 4);
            ps.addBatch();
            
            // Add Earned leave
            ps.setString(2, "Earned");
            ps.setInt(3, 2);
            ps.addBatch();
            
            // Execute batch insert
            ps.executeBatch();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public Map<String, Integer> getLeaveBalance(int employeeId) {
        Map<String, Integer> leaveBalance = new HashMap<>();
        String sql = "SELECT leave_type, balance FROM leave_balance WHERE employee_id = ?";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, employeeId);
            ResultSet rs = ps.executeQuery();
            
            while (rs.next()) {
                String leaveType = rs.getString("leave_type"); // This will fetch 'Sick', 'Casual', or 'Earned'
                int balance = rs.getInt("balance"); // This will fetch the balance value
                leaveBalance.put(leaveType, balance);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return leaveBalance;
    }


}
