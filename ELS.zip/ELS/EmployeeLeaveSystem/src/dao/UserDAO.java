package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import org.mindrot.jbcrypt.BCrypt;

import model.User;

public class UserDAO {

    // Method to register a new user (admin or employee)
    public boolean registerUser(User user) {
        String sql = "INSERT INTO users (username, password, email, role, department) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, user.getUsername());
            ps.setString(2, user.getPassword()); // Store hashed password in a real application
            ps.setString(3, user.getEmail());
            ps.setString(4, user.getRole());
            ps.setString(5, user.getDepartment());
            int rowsInserted = ps.executeUpdate();
            return rowsInserted > 0;
        } catch (SQLException e) {
            System.out.println("Error registering user: " + e.getMessage());
        }
        return false;
    }

    // Method to authenticate user login (validate credentials)
    public User authenticateUser(String username, String password) {
        String sql = "SELECT * FROM users WHERE username = ? AND password = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, username);
            ps.setString(2, password); // Password should be hashed in a real app
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    User user = new User();
                    user.setId(rs.getInt("id"));
                    user.setUsername(rs.getString("username"));
                    user.setPassword(rs.getString("password"));
                    user.setEmail(rs.getString("email"));
                    user.setRole(rs.getString("role"));
                    user.setDepartment(rs.getString("department"));
                    return user;
                }
            }
        } catch (SQLException e) {
            System.out.println("Error authenticating user: " + e.getMessage());
        }
        return null; // Return null if authentication fails
    }

    // Method to fetch user details by user ID
    public User getUserById(int userId) {
        String sql = "SELECT * FROM users WHERE id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, userId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    User user = new User();
                    user.setId(rs.getInt("id"));
                    user.setUsername(rs.getString("username"));
                    user.setEmail(rs.getString("email"));
                    user.setRole(rs.getString("role"));
                    user.setDepartment(rs.getString("department"));
                    return user;
                }
            }
        } catch (SQLException e) {
            System.out.println("Error fetching user details: " + e.getMessage());
        }
        return null;
    }

    public boolean updateUser(User user) {
        String sql;
        
        if (user.getPassword() != null && !user.getPassword().isEmpty()) {
            sql = "UPDATE users SET username = ?, email = ?, role = ?, department = ?, password = ? WHERE id = ?";
        } else {
            sql = "UPDATE users SET username = ?, email = ?, role = ?, department = ? WHERE id = ?";
        }

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, user.getUsername());
            ps.setString(2, user.getEmail());
            ps.setString(3, user.getRole());
            ps.setString(4, user.getDepartment());

            if (user.getPassword() != null && !user.getPassword().isEmpty()) {
                ps.setString(5, user.getPassword()); // Store hashed password in a real application
                ps.setInt(6, user.getId());
            } else {
                ps.setInt(5, user.getId());
            }

            int rowsUpdated = ps.executeUpdate();
            return rowsUpdated > 0;
        } catch (SQLException e) {
            e.printStackTrace(); // Log error for debugging
        }
        return false;
    }


    // Method to check if a username already exists during registration
    public boolean isUsernameTaken(String username) {
        String sql = "SELECT * FROM users WHERE username = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, username);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next(); // Return true if the username is already taken
            }
        } catch (SQLException e) {
            System.out.println("Error checking username: " + e.getMessage());
        }
        return false;
    }

    public User getUserByUsernameOrEmail(String usernameOrEmail) {
        String sql = "SELECT * FROM users WHERE username = ? OR email = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, usernameOrEmail);
            ps.setString(2, usernameOrEmail);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    User user = new User();
                    user.setId(rs.getInt("id"));
                    user.setUsername(rs.getString("username"));
                    user.setEmail(rs.getString("email"));
                    user.setRole(rs.getString("role"));
                    user.setDepartment(rs.getString("department"));
                    return user;
                }
            }
        } catch (SQLException e) {
            System.out.println("Error fetching user by username or email: " + e.getMessage());
        }
        return null;
    }

    // Method to save password reset token
    public boolean savePasswordResetToken(String resetToken, String username, Timestamp expiration) {
        String sql = "INSERT INTO password_resets (reset_token, username, expiration) VALUES (?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, resetToken);
            ps.setString(2, username);
            ps.setTimestamp(3, expiration);
            int rowsInserted = ps.executeUpdate();
            return rowsInserted > 0;
        } catch (SQLException e) {
            System.out.println("Error saving password reset token: " + e.getMessage());
        }
        return false;
    }

    // Method to reset the user's password
    public boolean resetPassword(String resetToken, String newPassword) {
        boolean isPasswordReset = false;
        try (Connection conn = DBConnection.getConnection()) {
            String query = "SELECT * FROM password_resets WHERE reset_token = ?";
            try (PreparedStatement ps = conn.prepareStatement(query)) {
                ps.setString(1, resetToken);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        Timestamp expiration = rs.getTimestamp("expiration");
                        long currentTime = System.currentTimeMillis();
                        if (currentTime < expiration.getTime()) {
                            String username = rs.getString("username");
                            String updateQuery = "UPDATE users SET password = ? WHERE username = ?";
                            try (PreparedStatement updateStmt = conn.prepareStatement(updateQuery)) {
                                updateStmt.setString(1, BCrypt.hashpw(newPassword, BCrypt.gensalt()));
                                updateStmt.setString(2, username);
                                int rowsUpdated = updateStmt.executeUpdate();
                                if (rowsUpdated > 0) {
                                    String deleteQuery = "DELETE FROM password_resets WHERE reset_token = ?";
                                    try (PreparedStatement deleteStmt = conn.prepareStatement(deleteQuery)) {
                                        deleteStmt.setString(1, resetToken);
                                        deleteStmt.executeUpdate();
                                    }
                                    isPasswordReset = true;
                                }
                            }
                        }
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return isPasswordReset;
    }

    public List<User> getAllUsers() {
        List<User> users = new ArrayList<>();
        String sql = "SELECT id, username, email, role, department FROM users";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                // Create User object and populate it with data from the ResultSet
                User user = new User();
                user.setId(rs.getInt("id"));
                user.setUsername(rs.getString("username"));
                user.setEmail(rs.getString("email"));
                user.setRole(rs.getString("role"));
                user.setDepartment(rs.getString("department"));
                
                // Add the user to the list
                users.add(user);
            }
        } catch (SQLException e) {
            System.out.println("Error fetching users: " + e.getMessage());
        }
        return users; // Return the list of users
    }

    public boolean deleteUser(int userId) {
        String sql = "DELETE FROM users WHERE id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, userId); // Set the user ID parameter
            
            int rowsDeleted = ps.executeUpdate(); // Execute the delete operation
            
            return rowsDeleted > 0; // Return true if at least one row is deleted, else false
        } catch (SQLException e) {
            System.out.println("Error deleting user: " + e.getMessage());
        }
        return false; // Return false if deletion failed
    }


        public List<User> searchUsers(String searchQuery) {
            List<User> users = new ArrayList<>();
            String sql = "SELECT * FROM users WHERE username LIKE ? OR email LIKE ?";
            
            try (Connection conn = DBConnection.getConnection();
                 PreparedStatement ps = conn.prepareStatement(sql)) {
                String searchTerm = "%" + searchQuery + "%";
                ps.setString(1, searchTerm);
                ps.setString(2, searchTerm);
                
                try (ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) {
                        User user = new User();
                        user.setId(rs.getInt("id"));
                        user.setUsername(rs.getString("username"));
                        user.setEmail(rs.getString("email"));
                        user.setRole(rs.getString("role"));
                        user.setDepartment(rs.getString("department"));
                        users.add(user);
                    }
                }
            } catch (SQLException e) {
                System.out.println("Error fetching users: " + e.getMessage());
            }
            return users;
        }

        public String getEmployeeId(User newUser) {
            String sql = "SELECT employeeId FROM users WHERE username = ?";  // Modify according to your actual schema
            String employeeId = null;
            
            try (Connection conn = DBConnection.getConnection();
                 PreparedStatement ps = conn.prepareStatement(sql)) {
                
                ps.setString(1, newUser.getUsername());  // Use the username to fetch the corresponding employeeId
                
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        employeeId = rs.getString("employeeId");  // Get the employeeId from the ResultSet
                    }
                }
            } catch (SQLException e) {
                System.out.println("Error fetching employee ID: " + e.getMessage());
            }
            
            return employeeId;
        }


       
    
}