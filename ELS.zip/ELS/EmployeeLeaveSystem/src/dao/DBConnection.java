package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {
    // Database credentials
    private static final String URL = "jdbc:mysql://localhost:3306/EmployeeLeaveSystem"; // Replace 'EmployeeLeaveSystem' with your database name
    private static final String USER = "root"; // Replace 'root' with your database username
    private static final String PASSWORD = "tiger"; // Replace 'password' with your database password
    private static final String DRIVER = "com.mysql.cj.jdbc.Driver"; // MySQL JDBC Driver

    // Method to establish a database connection
    public static Connection getConnection() {
        Connection conn = null;
        try {
            // Load the database driver
            Class.forName(DRIVER);

            // Create the connection
            conn = DriverManager.getConnection(URL, USER, PASSWORD);

        } catch (ClassNotFoundException e) {
            System.out.println("Database Driver not found: " + e.getMessage());
        } catch (SQLException e) {
            System.out.println("Failed to connect to the database: " + e.getMessage());
        }
        return conn;
    }

    // Method to close the connection
    public static void closeConnection(Connection conn) {
        try {
            if (conn != null && !conn.isClosed()) {
                conn.close();
            }
        } catch (SQLException e) {
            System.out.println("Failed to close the database connection: " + e.getMessage());
        }
    }
}
