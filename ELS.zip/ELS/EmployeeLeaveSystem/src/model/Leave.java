package model;

import java.util.Date;

public class Leave {
    private int leaveId;
    private int employeeId;
    private String leaveType;
    private Date startDate;
    private Date endDate;
    private String reason;
    private String status;
    private String comments;

    // Getters and Setters
    public int getLeaveId() {
        return leaveId;
    }

    public void setLeaveId(int leaveId) {
        this.leaveId = leaveId;
    }

    public int getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(int employeeId) {
        this.employeeId = employeeId;
    }

    public String getLeaveType() {
        return leaveType;
    }

    public void setLeaveType(String leaveType) {
        this.leaveType = leaveType;
    }

    public Date getStartDate() {
        return startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public Date getEndDate() {
        return endDate;
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }

    // Additional methods for calculating leave duration
    public long getLeaveDuration() {
        if (startDate != null && endDate != null) {
            long diffInMillis = endDate.getTime() - startDate.getTime();
            return diffInMillis / (1000 * 60 * 60 * 24) + 1; // Convert to days
        }
        return 0;
    }

    // Override toString for easy logging
    @Override
    public String toString() {
        return "Leave{" +
                "leaveId=" + leaveId +
                ", employeeId=" + employeeId +
                ", leaveType='" + leaveType + '\'' +
                ", startDate=" + startDate +
                ", endDate=" + endDate +
                ", reason='" + reason + '\'' +
                ", status='" + status + '\'' +
                ", comments='" + comments + '\'' +
                '}';
    }

    // Override equals and hashCode (optional, depends on usage)
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;

        Leave leave = (Leave) obj;

        return leaveId == leave.leaveId;
    }

    @Override
    public int hashCode() {
        return leaveId;
    }
}
