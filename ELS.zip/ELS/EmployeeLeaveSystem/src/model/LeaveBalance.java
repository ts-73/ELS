package model;

public class LeaveBalance {

    private int id;               // Unique identifier for the leave balance record
    private int employeeId;       // ID of the employee whose leave balance is being tracked
    private String leaveType;     // Type of leave (e.g., "Casual", "Sick")
    private int balance;          // The remaining balance of the specific leave type

    // Constructor
    public LeaveBalance() {}

    // Getters and setters for all attributes
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(int employeeId) {
        this.employeeId = employeeId;
    }

    public String getLeaveType() {
        return leaveType;
    }

    public void setLeaveType(String leaveType) {
        this.leaveType = leaveType;
    }

    public int getBalance() {
        return balance;
    }

    public void setBalance(int balance) {
        this.balance = balance;
    }

    // Optionally, override toString() for easy logging and debugging
    @Override
    public String toString() {
        return "LeaveBalance{" +
                "id=" + id +
                ", employeeId=" + employeeId +
                ", leaveType='" + leaveType + '\'' +
                ", balance=" + balance +
                '}';
    }

	public void setStatus(String status) {
		// TODO Auto-generated method stub
		
	}
}
